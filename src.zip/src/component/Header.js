import React from 'react'

const Header = () =>{
    return (
        <>
            <div className='container-fluid' style={{ background: '#141414', padding: '35px 0', color:'ghostwhite'}}>
                <div className='container'>
                    <h1 className='fontTitle' style={{color:'ghostwhite'}}>Dock-It! </h1>
                </div>
            </div>
        </>
    )
}

export default Header