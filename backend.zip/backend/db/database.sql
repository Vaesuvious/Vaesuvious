Use todos;

Select * From todonotes;